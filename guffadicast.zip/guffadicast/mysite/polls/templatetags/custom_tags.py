from django import template

register = template.Library()

@register.simple_tag


def get_half_content(description):
	new=[]
	for char in description:
		new.append(char)
		if char=='.':
			break
	str1 = ""
	return(str1.join(new))
