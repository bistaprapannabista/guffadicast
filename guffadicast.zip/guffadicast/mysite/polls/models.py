from django.db import models
from datetime import datetime

# Create your models here.

class Contact(models.Model):
	name=models.CharField(max_length=40)
	email=models.EmailField(max_length=70)
	phone=models.CharField(max_length=20)
	message=models.CharField(max_length=120)
	date=models.DateTimeField()


	def __str__(self):
		return self.name 


class User(models.Model):
	
	name=models.CharField(max_length=40)
	email=models.EmailField(max_length=70)
	phone=models.CharField(max_length=20)
	password=models.CharField(max_length=40)
	confirm_password=models.CharField(max_length=40)
	date=models.DateTimeField()
	isAdmin = models.BooleanField(default=False, blank=True)

	def __str__(self):
		return self.name

class Index(models.Model): 
	user_id=models.ForeignKey(User,on_delete=models.CASCADE)
	audioFile=models.FileField(upload_to='media')
	title=models.CharField(max_length=40)
	description=models.CharField(max_length=10000)
	date=models.DateTimeField()
	name=models.CharField(max_length=30)

	def __str__(self):
		return self.title

class Comment(models.Model):
	message = models.TextField()
	date = models.DateTimeField(default=datetime.now(), blank=True)
	user_id=models.ForeignKey(User,on_delete=models.CASCADE)
	post_id=models.ForeignKey(Index,on_delete=models.CASCADE)

	def __str__(self):
		return self.user_id.name


