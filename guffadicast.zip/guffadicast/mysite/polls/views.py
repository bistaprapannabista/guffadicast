from django.shortcuts import render, redirect
from datetime import datetime
from polls.models import Contact, User, Index, Comment
from django.contrib import messages
from django.contrib.sessions.models import Session
from django.http import HttpResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.

	
def index(request):
    post_list = Index.objects.all().order_by('-date')
    paginator = Paginator(post_list, 3)
    page = request.GET.get('page')
 
    try:
        posts = paginator.page(page)

    except PageNotAnInteger:
        posts = paginator.page(1)
 
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    return render(request, 'index.html', {'page':page,'posts':posts})



def contact(request):
	if request.method=="POST":
		name=request.POST['name']
		email=request.POST['email']
		phone=request.POST['phone']
		message=request.POST['message']
		contact=Contact(name=name,email=email.lower(),phone=phone,message=message,date=datetime.now())
		contact.save()
		messages.success(request,'Your message has been sent successfully.')
		return redirect('index')

	return render(request,'contact.html')


def login(request):
	if request.session.has_key('is_logged'):
		messages.info(request,'You are already logged in.')
		return redirect('index')

	if request.method=="POST":
		email=request.POST['email']
		password=request.POST['password']
		count=User.objects.filter(email=email,password=password).count()
		if count > 0:
			messages.success(request,'You are logged in successfully.')
			request.session['is_logged']=True
			request.session['is_admin'] = User.objects.values('isAdmin').filter(email=email,password=password)[0]['isAdmin']
			request.session['user_id']=User.objects.values('id').filter(email=email,password=password)[0]['id']
			request.session['user_name']=User.objects.values('name').filter(email=email,password=password)[0]['name']
			request.session['user_number']=User.objects.values('phone').filter(email=email,password=password)[0]['phone']
			request.session['user_email']=User.objects.values('email').filter(email=email,password=password)[0]['email']
			return redirect('index')
		else:
			messages.error(request, 'Please enter valid email and password')
			return redirect('login')

	return render(request,'login.html')

def signup(request):
	if request.method=="POST":
		name=request.POST['name']
		email=request.POST['email']
		phone=request.POST['phone']
		password=request.POST['password']
		confirm_password=request.POST['confirm_password']

		if(password!=confirm_password):
			messages.error(request, 'Make sure both password are same.')
			return redirect('signup')

		if(len(password)<7):
			messages.error(request, 'Your password must be atleast of 7 characters and better to use numbers in it.')
			return redirect('signup')

		user=User(name=name,email=email.lower(),phone=phone,password=password,confirm_password=confirm_password,date=datetime.now())
		user.save()	
		messages.success(request, 'Your account is created successfully.')
		return redirect('login')
		
	return render(request,'signup.html')



def logout(request):

	if request.session.has_key('is_logged'):
		del request.session['is_logged']
		del request.session['is_admin']
		del request.session['user_id']
		del request.session['user_name']
		del request.session['user_number']
		del request.session['user_email']
		messages.success(request,"You are logged out successfully")
		return redirect(login)

	messages.error(request,"You are already logged out you must login to logout")
	return redirect('login')

def upload(request):

	if request.method=="POST":
		name=request.POST['name']
		title=request.POST['title']
		description=request.POST['description']
		files=request.FILES['file']
		user_id=request.session['user_id']
		index=Index(name=name,title=title,description=description,audioFile=files,date=datetime.now())
		index.user_id_id=user_id
		index.save()
		messages.success(request,'Your post has been posted successfully.')
		return redirect('index')

	if request.session['is_admin']:
		return render(request,'upload.html')


def readmore(request,id):
	if request.method=="POST":
		message=request.POST['message']
		user_id=request.POST['user_id']
		post_id = id
		if request.session.has_key('is_logged'):
			query = Comment(message=message)
			query.post_id_id = post_id
			query.user_id_id = user_id
			query.save()

		else:
			messages.info(request,'You must login to comment')
			return redirect('login')
		
	data=Index.objects.get(id=id)
	comment=Comment.objects.all().filter(post_id=id)
	context={'data':data,'comments':comment}
	return render(request,'readmore.html',context)


def message(request):
	if request.session['is_admin']:
		fetch_data=Contact.objects.all()
		context={'data':fetch_data}
		return render(request,'message.html',context)

def search(request):
	query = request.GET['query']
	allPosts=Index.objects.filter(title__icontains=query)
	parms = {'allPosts':allPosts}
	return render(request,'search.html',parms)